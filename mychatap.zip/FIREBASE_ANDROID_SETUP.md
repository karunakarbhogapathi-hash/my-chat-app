# MyChatAp — Firebase & Android APK Setup Guide

## 1. Architecture Overview
**MyChatAp** is a native Android messaging application built with **Kotlin**, **Jetpack Compose**, **Material Design 3**, **Firebase Authentication (Credential Manager Google Sign-In)**, and **Cloud Firestore (Enterprise Edition)** with zero-trust security rules.

- **Application ID:** `com.aistudio.mychatap.vqrkln`
- **Provisioned Firebase Project ID:** `gen-lang-client-0268803464`
- **Provisioned Named Firestore Database:** `ai-studio-android-mychatap-5890835e-f5cf-49d3-8e4d-8eae6488dbd3`

## 2. Pre-Provisioned vs. Console-Configured Capabilities

### Automatically Provisioned in AI Studio
- **Cloud Firestore (Enterprise Edition)** with deployed zero-trust `firestore.rules`.
- **Firebase Authentication with Google Sign-In** via Jetpack `CredentialManager` (`GetSignInWithGoogleOption` and `GetGoogleIdOption`).
- **`app/google-services.json`** and **`app/src/main/res/values/firebase_applet_config.xml`** with registered debug SHA-1/SHA-256 certificates.

### Optional Manual Console Configurations
If you export the project and want to enable additional Firebase providers beyond the pre-provisioned Google Sign-In and Firestore database:
1. **Phone Number OTP Authentication:**
   - Open [Firebase Console → Authentication → Sign-in method](https://console.firebase.google.com/project/gen-lang-client-0268803464/authentication/providers).
   - Enable the **Phone** provider, configure Play Integrity / SafetyNet verification, and add test phone numbers if testing on emulators.
2. **Firebase Cloud Storage (Large Media Files):**
   - By default, **MyChatAp** compresses gallery photos on-device into lightweight JPEG payloads (`< 120 KB`) synchronized directly through Firestore so image sharing works out of the box without extra bucket setup.
   - For high-resolution video or uncompressed documents, enable **Storage** in the Firebase Console and add `com.google.firebase:firebase-storage` under the Firebase BoM.
3. **Firebase Cloud Messaging (Background Push Notifications):**
   - Foreground and active-listener message/call alerts are delivered natively via Android `NotificationManager` (`POST_NOTIFICATIONS`).
   - For wake-from-killed background push delivery, enable **Cloud Messaging** in Firebase Console and deploy a Cloud Function triggered on `/chats/{chatId}/messages/{messageId}` creation.
4. **WebRTC TURN/STUN Relay for Cross-NAT Media Streams:**
   - Real-time call signaling (`ringing`, `accepted`, `declined`, `ended`, `missed`, SDP Offer/Answer, mute/video state) runs live over `/calls/{callId}` in Firestore, paired with local CameraX preview and `AudioManager` controls.
   - To stream peer-to-peer RTP audio/video across strict symmetric NATs in production, add a WebRTC engine (`io.getstream:stream-webrtc-android`) with STUN (`stun:stun.l.google.com:19302`) and a TURN server.

## 3. Building & Exporting an Android APK / AAB

### In Google AI Studio
- Open the **Settings / Export** menu in AI Studio to **Generate APK / AAB** directly, **Export as ZIP**, or **Push to GitHub**.

### Building Locally with Android Studio or Gradle
1. Ensure **JDK 17+** and **Android SDK (API 36)** are installed (`ANDROID_SDK_ROOT` set).
2. Place your `google-services.json` in `app/google-services.json` and register your local debug/release keystore SHA-1 & SHA-256 fingerprints in Firebase Project Settings.
3. Build the debug APK:
   ```bash
   ./gradlew :app:assembleDebug
   ```
   The installable APK is output to `app/build/outputs/apk/debug/app-debug.apk`.
4. Deploy updated Firestore rules if modified:
   ```bash
   firebase deploy --only firestore:rules
   ```
