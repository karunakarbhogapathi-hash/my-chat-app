package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.OperationType
import com.example.data.handleFirestoreError
import com.example.data.model.CallSession
import com.example.data.model.ChatMessage
import com.example.data.model.ChatRoom
import com.example.data.model.StatusPost
import com.example.data.model.UserPrivateSettings
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import java.util.UUID
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class ChatRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    // Secondary constructor resolving provisioned named database ID from firebase_applet_config.xml
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    // --- Profile & Private Settings ---

    suspend fun ensureProfileBootstrapped(
        displayName: String,
        email: String,
        photoUrl: String = ""
    ): UserProfile {
        val uid = requireUserId()
        val profileRef = db.collection("profiles").document(uid)
        val privateRef = db.collection("user_private").document(uid)

        try {
            val existingSnap = profileRef.get().await()
            val cleanName = displayName.trim().ifBlank {
                email.substringBefore("@").ifBlank { "MyChatAp User" }
            }.take(80)
            val defaultHandle = cleanName
                .lowercase()
                .replace(Regex("[^a-z0-9_]"), "_")
                .trim('_')
                .let { if (it.length < 2) "user_${uid.take(6).lowercase()}" else it }
                .take(36)

            if (!existingSnap.exists()) {
                val profilePayload = mapOf(
                    "userId" to uid,
                    "displayName" to cleanName,
                    "handle" to defaultHandle,
                    "about" to "Hey there! I am using MyChatAp.",
                    "photoData" to photoUrl.take(200000),
                    "isOnline" to true,
                    "showLastSeen" to true,
                    "isDiscoverable" to true,
                    "lastSeenAt" to FieldValue.serverTimestamp(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
                profileRef.set(profilePayload).await()
            } else {
                profileRef.update(
                    mapOf(
                        "isOnline" to true,
                        "lastSeenAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            }

            val privateSnap = privateRef.get().await()
            if (!privateSnap.exists()) {
                val privatePayload = mapOf(
                    "userId" to uid,
                    "email" to email.take(160),
                    "phoneNumber" to "",
                    "readReceiptsEnabled" to true,
                    "notificationsEnabled" to true,
                    "callNotificationsEnabled" to true,
                    "darkModePreference" to "system",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
                privateRef.set(privatePayload).await()
            }

            val finalSnap = profileRef.get().await()
            return finalSnap.toObject(
                UserProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: UserProfile(id = uid, userId = uid, displayName = cleanName, handle = defaultHandle)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, profileRef.path)
            throw e
        }
    }

    fun observeMyProfile(userId: String): Flow<UserProfile?> {
        val docRef = db.collection("profiles").document(userId)
        return docRef.snapshots()
            .map { snap ->
                if (snap.exists()) {
                    snap.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.GET, docRef.path)
                throw error
            }
    }

    fun observeMyPrivateSettings(userId: String): Flow<UserPrivateSettings?> {
        val docRef = db.collection("user_private").document(userId)
        return docRef.snapshots()
            .map { snap ->
                if (snap.exists()) {
                    snap.toObject(UserPrivateSettings::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.GET, docRef.path)
                throw error
            }
    }

    fun observeDiscoverableProfiles(): Flow<List<UserProfile>> {
        val path = "profiles"
        return db.collection(path)
            .whereEqualTo("isDiscoverable", true)
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.sortedBy { it.displayName.lowercase() }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    suspend fun updateProfile(
        displayName: String,
        handle: String,
        about: String,
        photoData: String,
        showLastSeen: Boolean,
        isDiscoverable: Boolean
    ) {
        val uid = requireUserId()
        val docRef = db.collection("profiles").document(uid)
        val sanitizedHandle = handle.trim().lowercase()
            .replace(Regex("[^a-z0-9_\\-]"), "_")
            .let { if (it.length < 2) "user_${uid.take(6).lowercase()}" else it }
            .take(40)
        try {
            docRef.update(
                mapOf(
                    "displayName" to displayName.trim().ifBlank { "MyChatAp User" }.take(80),
                    "handle" to sanitizedHandle,
                    "about" to about.trim().take(200),
                    "photoData" to photoData.take(240000),
                    "isOnline" to true,
                    "showLastSeen" to showLastSeen,
                    "isDiscoverable" to isDiscoverable,
                    "lastSeenAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun updatePresence(isOnline: Boolean) {
        val uid = auth.currentUser?.uid ?: return
        val docRef = db.collection("profiles").document(uid)
        try {
            val snap = docRef.get().await()
            if (snap.exists()) {
                docRef.update(
                    mapOf(
                        "isOnline" to isOnline,
                        "lastSeenAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
        }
    }

    suspend fun updatePrivateSettings(
        phoneNumber: String,
        readReceiptsEnabled: Boolean,
        notificationsEnabled: Boolean,
        callNotificationsEnabled: Boolean,
        darkModePreference: String
    ) {
        val uid = requireUserId()
        val docRef = db.collection("user_private").document(uid)
        try {
            docRef.update(
                mapOf(
                    "phoneNumber" to phoneNumber.trim().take(32),
                    "readReceiptsEnabled" to readReceiptsEnabled,
                    "notificationsEnabled" to notificationsEnabled,
                    "callNotificationsEnabled" to callNotificationsEnabled,
                    "darkModePreference" to if (darkModePreference in listOf("system", "light", "dark")) darkModePreference else "system",
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    // --- Direct & Group Chats ---

    fun observeMyChats(userId: String): Flow<List<ChatRoom>> {
        val path = "chats"
        return db.collection(path)
            .whereArrayContains("participantIds", userId)
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(ChatRoom::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    fun observeChat(chatId: String): Flow<ChatRoom?> {
        val docRef = db.collection("chats").document(chatId)
        return docRef.snapshots()
            .map { snap ->
                if (snap.exists()) {
                    snap.toObject(ChatRoom::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.GET, docRef.path)
                throw error
            }
    }

    suspend fun getOrCreateDirectChat(otherUserId: String, otherDisplayName: String): String {
        val uid = requireUserId()
        require(otherUserId.isNotBlank() && otherUserId != uid) { "Select another contact to chat with." }
        val pairKey = listOf(uid, otherUserId).sorted().joinToString("_").take(260)
        val chatsRef = db.collection("chats")
        try {
            val myChatsSnap = chatsRef.whereArrayContains("participantIds", uid).get().await()
            val existing = myChatsSnap.documents.firstOrNull { doc ->
                doc.getString("chatType") == "direct" && doc.getString("directPairKey") == pairKey
            }
            if (existing != null) {
                return existing.id
            }

            val chatId = "dm_${UUID.randomUUID().toString().replace("-", "")}"
            val payload = mapOf(
                "chatType" to "direct",
                "directPairKey" to pairKey,
                "title" to otherDisplayName.trim().ifBlank { "Direct Chat" }.take(80),
                "description" to "",
                "photoData" to "",
                "createdBy" to uid,
                "participantIds" to listOf(uid, otherUserId),
                "adminIds" to listOf(uid, otherUserId),
                "lastMessageText" to "",
                "lastMessageSenderId" to "",
                "lastMessageSenderName" to "",
                "lastMessageType" to "none",
                "typingUserIds" to emptyList<String>(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            chatsRef.document(chatId).set(payload).await()
            return chatId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, chatsRef.path)
            throw e
        }
    }

    suspend fun createGroupChat(
        title: String,
        description: String,
        photoData: String,
        memberIds: List<String>
    ): String {
        val uid = requireUserId()
        val allParticipants = (listOf(uid) + memberIds).map { it.trim() }.filter { it.isNotBlank() }.distinct().take(20)
        require(allParticipants.size >= 2) { "Select at least 1 contact to create a group." }
        val chatId = "grp_${UUID.randomUUID().toString().replace("-", "")}"
        val docRef = db.collection("chats").document(chatId)
        try {
            val payload = mapOf(
                "chatType" to "group",
                "directPairKey" to "",
                "title" to title.trim().ifBlank { "New Group" }.take(80),
                "description" to description.trim().take(300),
                "photoData" to photoData.take(240000),
                "createdBy" to uid,
                "participantIds" to allParticipants,
                "adminIds" to listOf(uid),
                "lastMessageText" to "Group created",
                "lastMessageSenderId" to uid,
                "lastMessageSenderName" to "System",
                "lastMessageType" to "text",
                "typingUserIds" to emptyList<String>(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            docRef.set(payload).await()
            return chatId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun updateGroupDetails(
        chatId: String,
        title: String,
        description: String,
        photoData: String,
        participantIds: List<String>,
        adminIds: List<String>
    ) {
        requireUserId()
        val docRef = db.collection("chats").document(chatId)
        try {
            docRef.update(
                mapOf(
                    "title" to title.trim().ifBlank { "Group" }.take(80),
                    "description" to description.trim().take(300),
                    "photoData" to photoData.take(240000),
                    "participantIds" to participantIds.distinct().take(20),
                    "adminIds" to adminIds.distinct().take(20),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun setTypingIndicator(chatId: String, currentTypingIds: List<String>, isTyping: Boolean) {
        val uid = auth.currentUser?.uid ?: return
        val updatedList = if (isTyping) {
            (currentTypingIds + uid).distinct().take(20)
        } else {
            currentTypingIds.filterNot { it == uid }
        }
        if (updatedList == currentTypingIds) return
        val docRef = db.collection("chats").document(chatId)
        try {
            docRef.update(
                mapOf(
                    "typingUserIds" to updatedList,
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
        }
    }

    // --- Real-Time Messages ---

    fun observeMessages(chatId: String, userId: String): Flow<List<ChatMessage>> {
        val path = "chats/$chatId/messages"
        return db.collection("chats").document(chatId).collection("messages")
            .whereArrayContains("participantIds", userId)
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(ChatMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.sortedBy { it.createdAt ?: Timestamp.now() }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    suspend fun sendMessage(
        chatId: String,
        participantIds: List<String>,
        senderName: String,
        type: String,
        text: String,
        imageData: String = "",
        replyToMessageId: String = "",
        replyPreviewText: String = "",
        currentTypingIds: List<String> = emptyList()
    ): String {
        val uid = requireUserId()
        val msgId = "msg_${UUID.randomUUID().toString().replace("-", "")}"
        val msgRef = db.collection("chats").document(chatId).collection("messages").document(msgId)
        val chatRef = db.collection("chats").document(chatId)

        val validType = if (type in listOf("text", "emoji", "image")) type else "text"
        val cleanText = text.trim().take(4000)
        val preview = when (validType) {
            "image" -> if (cleanText.isNotEmpty()) "📷 $cleanText".take(500) else "📷 Photo"
            else -> cleanText.take(500)
        }

        try {
            val messagePayload = mapOf(
                "chatId" to chatId,
                "senderId" to uid,
                "senderName" to senderName.trim().ifBlank { "User" }.take(80),
                "participantIds" to participantIds.distinct().take(20),
                "type" to validType,
                "text" to cleanText,
                "imageData" to imageData.take(240000),
                "replyToMessageId" to replyToMessageId.take(128),
                "replyPreviewText" to replyPreviewText.take(200),
                "status" to "sent",
                "deliveredTo" to emptyList<String>(),
                "readBy" to emptyList<String>(),
                "isEdited" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            msgRef.set(messagePayload).await()

            chatRef.update(
                mapOf(
                    "lastMessageText" to preview,
                    "lastMessageSenderId" to uid,
                    "lastMessageSenderName" to senderName.trim().ifBlank { "User" }.take(80),
                    "lastMessageType" to validType,
                    "typingUserIds" to currentTypingIds.filterNot { it == uid },
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()
            return msgId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, msgRef.path)
            throw e
        }
    }

    suspend fun markMessagesRead(
        chatId: String,
        messages: List<ChatMessage>,
        readReceiptsEnabled: Boolean
    ) {
        val uid = auth.currentUser?.uid ?: return
        val unreadIncoming = messages.filter { msg ->
            msg.senderId != uid && !msg.readBy.contains(uid) && (!msg.deliveredTo.contains(uid) || readReceiptsEnabled)
        }
        for (msg in unreadIncoming) {
            if (msg.id.isBlank()) continue
            val docRef = db.collection("chats").document(chatId).collection("messages").document(msg.id)
            val newDelivered = (msg.deliveredTo + uid).distinct().take(20)
            val newRead = if (readReceiptsEnabled) (msg.readBy + uid).distinct().take(20) else msg.readBy
            val targetStatus = when {
                msg.status == "read" -> "read"
                readReceiptsEnabled -> "read"
                else -> "delivered"
            }
            try {
                docRef.update(
                    mapOf(
                        "status" to targetStatus,
                        "deliveredTo" to newDelivered,
                        "readBy" to newRead,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            }
        }
    }

    suspend fun deleteMessage(chatId: String, messageId: String) {
        requireUserId()
        val docRef = db.collection("chats").document(chatId).collection("messages").document(messageId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // --- Status Updates (24h Stories) ---

    fun observeContactStatuses(): Flow<List<StatusPost>> {
        val path = "statuses"
        val cutoffMillis = System.currentTimeMillis() - 24L * 60L * 60L * 1000L
        return db.collection(path)
            .whereEqualTo("visibility", "contacts")
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(StatusPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.filter { post ->
                    val tsMillis = post.createdAt?.toDate()?.time ?: System.currentTimeMillis()
                    tsMillis >= cutoffMillis
                }.sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    suspend fun postStatus(
        authorName: String,
        authorPhotoData: String,
        mediaType: String,
        caption: String,
        imageData: String = "",
        backgroundColorHex: String = "#075E54",
        visibility: String = "contacts"
    ): String {
        val uid = requireUserId()
        val statusId = "st_${UUID.randomUUID().toString().replace("-", "")}"
        val docRef = db.collection("statuses").document(statusId)
        val validMedia = if (mediaType in listOf("text", "image")) mediaType else "text"
        val validHex = if (backgroundColorHex.matches(Regex("^#[0-9A-Fa-f]{6,8}$"))) backgroundColorHex else "#075E54"
        try {
            val payload = mapOf(
                "authorId" to uid,
                "authorName" to authorName.trim().ifBlank { "User" }.take(80),
                "authorPhotoData" to authorPhotoData.take(240000),
                "mediaType" to validMedia,
                "caption" to caption.trim().take(700),
                "imageData" to imageData.take(240000),
                "backgroundColorHex" to validHex,
                "visibility" to if (visibility in listOf("contacts", "private")) visibility else "contacts",
                "viewerIds" to emptyList<String>(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            docRef.set(payload).await()
            return statusId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun markStatusViewed(status: StatusPost) {
        val uid = auth.currentUser?.uid ?: return
        if (status.id.isBlank() || status.authorId == uid || status.viewerIds.contains(uid)) return
        val docRef = db.collection("statuses").document(status.id)
        try {
            docRef.update(
                mapOf(
                    "viewerIds" to (status.viewerIds + uid).distinct().take(100),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
        }
    }

    suspend fun deleteStatus(statusId: String) {
        requireUserId()
        val docRef = db.collection("statuses").document(statusId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // --- Real-Time Audio & Video Call Signaling ---

    fun observeCalls(userId: String): Flow<List<CallSession>> {
        val path = "calls"
        return db.collection(path)
            .whereArrayContains("participantIds", userId)
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(CallSession::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    fun observeCallSession(callId: String): Flow<CallSession?> {
        val docRef = db.collection("calls").document(callId)
        return docRef.snapshots()
            .map { snap ->
                if (snap.exists()) {
                    snap.toObject(CallSession::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.GET, docRef.path)
                throw error
            }
    }

    suspend fun startCall(
        callerName: String,
        callerPhotoData: String,
        receiverId: String,
        receiverName: String,
        receiverPhotoData: String,
        callType: String
    ): String {
        val uid = requireUserId()
        require(receiverId.isNotBlank() && receiverId != uid) { "Invalid call recipient." }
        val callId = "call_${UUID.randomUUID().toString().replace("-", "")}"
        val docRef = db.collection("calls").document(callId)
        val validType = if (callType == "video") "video" else "audio"
        try {
            val payload = mapOf(
                "callerId" to uid,
                "callerName" to callerName.trim().ifBlank { "Caller" }.take(80),
                "callerPhotoData" to callerPhotoData.take(240000),
                "receiverId" to receiverId,
                "receiverName" to receiverName.trim().ifBlank { "Contact" }.take(80),
                "receiverPhotoData" to receiverPhotoData.take(240000),
                "participantIds" to listOf(uid, receiverId),
                "callType" to validType,
                "status" to "ringing",
                "sdpOffer" to "v=0\r\no=mychatap 1 1 IN IP4 0.0.0.0\r\ns=MyChatApSession\r\nm=$validType 9 UDP/TLS/RTP/SAVPF 111",
                "sdpAnswer" to "",
                "isMutedCaller" to false,
                "isMutedReceiver" to false,
                "isVideoEnabledCaller" to (validType == "video"),
                "isVideoEnabledReceiver" to (validType == "video"),
                "durationSeconds" to 0L,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            docRef.set(payload).await()
            return callId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun respondToCall(callId: String, accept: Boolean, isVideoCall: Boolean) {
        requireUserId()
        val docRef = db.collection("calls").document(callId)
        try {
            val updates = if (accept) {
                mapOf(
                    "status" to "accepted",
                    "sdpAnswer" to "v=0\r\no=mychatap-answer 1 1 IN IP4 0.0.0.0\r\ns=Accepted",
                    "isMutedReceiver" to false,
                    "isVideoEnabledReceiver" to isVideoCall,
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            } else {
                mapOf(
                    "status" to "declined",
                    "sdpAnswer" to "",
                    "isMutedReceiver" to false,
                    "isVideoEnabledReceiver" to false,
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            }
            docRef.update(updates).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun updateCallMediaState(
        callId: String,
        isCaller: Boolean,
        isMuted: Boolean,
        isVideoEnabled: Boolean
    ) {
        requireUserId()
        val docRef = db.collection("calls").document(callId)
        val updates = if (isCaller) {
            mapOf(
                "isMutedCaller" to isMuted,
                "isVideoEnabledCaller" to isVideoEnabled,
                "updatedAt" to FieldValue.serverTimestamp(),
            )
        } else {
            mapOf(
                "isMutedReceiver" to isMuted,
                "isVideoEnabledReceiver" to isVideoEnabled,
                "updatedAt" to FieldValue.serverTimestamp(),
            )
        }
        try {
            docRef.update(updates).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
        }
    }

    suspend fun endCall(callId: String, currentStatus: String, durationSeconds: Long) {
        requireUserId()
        if (currentStatus in listOf("declined", "ended", "missed")) return
        val docRef = db.collection("calls").document(callId)
        val finalStatus = if (currentStatus == "ringing" && durationSeconds == 0L) "missed" else "ended"
        try {
            docRef.update(
                mapOf(
                    "status" to finalStatus,
                    "durationSeconds" to durationSeconds.coerceIn(0L, 86400L),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
        }
    }
}
