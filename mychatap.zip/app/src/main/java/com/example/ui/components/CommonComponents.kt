package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.LocalChatColors
import com.example.ui.theme.OnlineDotGreen
import com.example.util.MediaUtils
import kotlin.math.abs

private val AvatarBgPalette = listOf(
    Color(0xFF075E54),
    Color(0xFF128C7E),
    Color(0xFF1E6F5C),
    Color(0xFF2B5876),
    Color(0xFF5D4E6D),
    Color(0xFF3E6B48),
)

@Composable
fun AvatarImage(
    photoData: String,
    displayName: String,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    isGroup: Boolean = false,
    isOnline: Boolean = false,
    hasUnseenStatusRing: Boolean = false,
    hasSeenStatusRing: Boolean = false
) {
    val decodedBitmap = remember(photoData) {
        if (photoData.startsWith("data:image")) {
            MediaUtils.decodeDataUriToImageBitmap(photoData)
        } else {
            null
        }
    }

    val initials = remember(displayName) {
        displayName.trim()
            .split(Regex("\\s+"))
            .filter { it.isNotEmpty() }
            .take(2)
            .joinToString("") { it.first().uppercaseChar().toString() }
            .ifBlank { "?" }
    }

    val bgTint = remember(displayName) {
        AvatarBgPalette[abs(displayName.hashCode()) % AvatarBgPalette.size]
    }

    Box(modifier = modifier.size(size)) {
        val ringModifier = when {
            hasUnseenStatusRing -> Modifier
                .border(2.5.dp, EmeraldAccent, CircleShape)
                .padding(3.dp)
            hasSeenStatusRing -> Modifier
                .border(2.dp, MaterialTheme.colorScheme.outline, CircleShape)
                .padding(3.dp)
            else -> Modifier
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .then(ringModifier)
                .clip(CircleShape)
                .background(bgTint),
            contentAlignment = Alignment.Center
        ) {
            when {
                decodedBitmap != null -> {
                    Image(
                        bitmap = decodedBitmap,
                        contentDescription = "$displayName profile photo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
                photoData.startsWith("http") -> {
                    AsyncImage(
                        model = photoData,
                        contentDescription = "$displayName profile photo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
                isGroup -> {
                    Icon(
                        imageVector = Icons.Filled.Groups,
                        contentDescription = "$displayName group icon",
                        tint = Color.White,
                        modifier = Modifier.size(size * 0.54f)
                    )
                }
                else -> {
                    Text(
                        text = initials,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = (size.value * 0.36f).sp
                    )
                }
            }
        }

        if (isOnline && !isGroup) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size((size.value * 0.27f).coerceAtLeast(11f).dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(2.dp)
                    .clip(CircleShape)
                    .background(OnlineDotGreen)
            )
        }
    }
}

@Composable
fun MessageReceiptIcon(
    status: String,
    modifier: Modifier = Modifier
) {
    val chatColors = LocalChatColors.current
    when (status) {
        "read" -> Icon(
            imageVector = Icons.Filled.DoneAll,
            contentDescription = "Read",
            tint = chatColors.readTick,
            modifier = modifier.size(16.dp)
        )
        "delivered" -> Icon(
            imageVector = Icons.Filled.DoneAll,
            contentDescription = "Delivered",
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
            modifier = modifier.size(16.dp)
        )
        else -> Icon(
            imageVector = Icons.Filled.Check,
            contentDescription = "Sent",
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
            modifier = modifier.size(15.dp)
        )
    }
}

private val QuickEmojis = listOf(
    "😀", "😂", "😍", "🥰", "😎", "🤩", "🙏", "🔥",
    "🎉", "👍", "❤️", "🙌", "✨", "🤝", "💯", "🤔",
    "🥳", "😊", "👏", "💚", "🚀", "🌟", "☕", "📸"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EmojiPickerTray(
    onEmojiSelected: (String) -> Unit,
    onSendStandaloneEmoji: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 3.dp
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Tap to insert • Tap badge to send jumbo emoji",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                QuickEmojis.forEach { emoji ->
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
                            .clickable { onEmojiSelected(emoji) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = emoji, fontSize = 22.sp)
                    }
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("❤️", "😂", "🔥", "👍", "🎉").forEach { quick ->
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = EmeraldDeep.copy(alpha = 0.1f),
                        modifier = Modifier.clickable { onSendStandaloneEmoji(quick) }
                    ) {
                        Text(
                            text = "Send $quick",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupGuideBottomSheet(
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Outlined.Security,
                    contentDescription = null,
                    tint = EmeraldDeep,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.size(10.dp))
                Text(
                    text = "Firebase & Android APK Guide",
                    style = MaterialTheme.typography.titleLarge
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Active Pre-Provisioned Backend",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "• Cloud Firestore Enterprise database & zero-trust rules are live.\n" +
                    "• Google Sign-In via Jetpack Credential Manager is pre-provisioned.\n" +
                    "• Real-time 1:1 chats, group chats, compressed photo sharing, 24h status updates, presence, and live call signaling run directly on Firestore.",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 4.dp)
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 14.dp))

            Text(
                text = "Enabling Optional Console Providers",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "1. Phone Number OTP Auth: Open Firebase Console → Authentication → Sign-in method → enable Phone provider and Play Integrity.\n" +
                    "2. Firebase Storage: For uncompressed video/files > 1 MB, enable Storage in Firebase Console.\n" +
                    "3. FCM Background Push: Enable Cloud Messaging in Firebase Console and deploy a Cloud Function trigger on /chats/{chatId}/messages.\n" +
                    "4. Production APK Export: Use AI Studio's Export menu to generate a signed APK/AAB or run ./gradlew :app:assembleDebug locally.",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onDismiss) {
                    Text("Got it")
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
