package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.model.CallSession
import com.example.ui.components.AvatarImage
import com.example.ui.theme.CallDangerRed
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.EmeraldDeep
import com.example.util.TimeFormatUtils
import kotlinx.coroutines.delay

@Composable
fun ActiveCallOverlay(
    currentUserId: String,
    call: CallSession,
    onAnswer: () -> Unit,
    onDecline: () -> Unit,
    onUpdateMedia: (isMuted: Boolean, isVideoEnabled: Boolean) -> Unit,
    onEndCall: (durationSeconds: Long) -> Unit,
    onDismissTerminal: () -> Unit
) {
    val context = LocalContext.current
    val isCaller = call.callerId == currentUserId
    val peerName = if (isCaller) call.receiverName else call.callerName
    val peerPhoto = if (isCaller) call.receiverPhotoData else call.callerPhotoData
    val isIncomingRinging = !isCaller && call.status == "ringing"

    var isMuted by remember { mutableStateOf(false) }
    var isVideoEnabled by remember(call.callType) { mutableStateOf(call.callType == "video") }
    var isSpeakerOn by remember { mutableStateOf(call.callType == "video") }
    var elapsedSeconds by remember { mutableLongStateOf(0L) }

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        hasMicPermission = grants[Manifest.permission.RECORD_AUDIO] == true || hasMicPermission
        hasCameraPermission = grants[Manifest.permission.CAMERA] == true || hasCameraPermission
    }

    LaunchedEffect(call.id) {
        val perms = if (call.callType == "video") {
            arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
        } else {
            arrayOf(Manifest.permission.RECORD_AUDIO)
        }
        permissionsLauncher.launch(perms)
    }

    // Speakerphone routing via AudioManager
    DisposableEffect(isSpeakerOn) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        @Suppress("DEPRECATION")
        audioManager?.isSpeakerphoneOn = isSpeakerOn
        onDispose {
            @Suppress("DEPRECATION")
            audioManager?.isSpeakerphoneOn = false
        }
    }

    // Live timer while call is accepted
    LaunchedEffect(call.status) {
        if (call.status == "accepted") {
            while (true) {
                delay(1000L)
                elapsedSeconds += 1L
            }
        } else if (call.status in listOf("declined", "ended", "missed")) {
            delay(1400L)
            onDismissTerminal()
        }
    }

    val peerMuted = if (isCaller) call.isMutedReceiver else call.isMutedCaller

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF062C27), Color(0xFF0B141A))
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .testTag("active_call_overlay")
    ) {
        // Real CameraX Local Video Preview when video mode is enabled and granted
        if (call.callType == "video" && isVideoEnabled && hasCameraPermission) {
            CameraPreviewSurface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(18.dp)
                    .width(120.dp)
                    .height(172.dp)
                    .clip(RoundedCornerShape(18.dp))
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Status Header
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color.White.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = if (call.callType == "video") "MyChatAp Video Call • Live Signaling"
                        else "MyChatAp Voice Call • Live Signaling",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White.copy(alpha = 0.9f),
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.height(34.dp))

                AvatarImage(
                    photoData = peerPhoto,
                    displayName = peerName,
                    size = 112.dp
                )

                Spacer(modifier = Modifier.height(18.dp))

                Text(
                    text = peerName,
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                val statusLine = when (call.status) {
                    "ringing" -> if (isIncomingRinging) "Incoming ${call.callType} call…" else "Ringing…"
                    "accepted" -> TimeFormatUtils.formatDurationSeconds(elapsedSeconds)
                    "declined" -> "Call declined"
                    "missed" -> "Missed call"
                    else -> "Call ended"
                }

                Text(
                    text = statusLine,
                    style = MaterialTheme.typography.titleMedium,
                    color = EmeraldAccent
                )

                if (call.status == "accepted" && peerMuted) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "$peerName is muted",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.72f)
                    )
                }
            }

            // Bottom Call Controls
            if (isIncomingRinging) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        FloatingActionButton(
                            onClick = onDecline,
                            containerColor = CallDangerRed,
                            contentColor = Color.White,
                            shape = CircleShape,
                            modifier = Modifier
                                .size(68.dp)
                                .testTag("decline_call_button")
                        ) {
                            Icon(Icons.Filled.CallEnd, contentDescription = "Decline call", modifier = Modifier.size(30.dp))
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Decline", color = Color.White, style = MaterialTheme.typography.labelMedium)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        FloatingActionButton(
                            onClick = onAnswer,
                            containerColor = EmeraldAccent,
                            contentColor = Color(0xFF043927),
                            shape = CircleShape,
                            modifier = Modifier
                                .size(68.dp)
                                .testTag("answer_call_button")
                        ) {
                            Icon(Icons.Filled.Call, contentDescription = "Answer call", modifier = Modifier.size(30.dp))
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Answer", color = Color.White, style = MaterialTheme.typography.labelMedium)
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    color = Color.White.copy(alpha = 0.1f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 16.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FloatingActionButton(
                            onClick = { isSpeakerOn = !isSpeakerOn },
                            containerColor = if (isSpeakerOn) Color.White else Color.White.copy(alpha = 0.18f),
                            contentColor = if (isSpeakerOn) EmeraldDeep else Color.White,
                            shape = CircleShape,
                            modifier = Modifier.size(54.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = "Toggle speaker")
                        }

                        if (call.callType == "video") {
                            FloatingActionButton(
                                onClick = {
                                    isVideoEnabled = !isVideoEnabled
                                    onUpdateMedia(isMuted, isVideoEnabled)
                                },
                                containerColor = if (!isVideoEnabled) Color.White else Color.White.copy(alpha = 0.18f),
                                contentColor = if (!isVideoEnabled) EmeraldDeep else Color.White,
                                shape = CircleShape,
                                modifier = Modifier.size(54.dp)
                            ) {
                                Icon(
                                    imageVector = if (isVideoEnabled) Icons.Filled.Videocam else Icons.Filled.VideocamOff,
                                    contentDescription = "Toggle camera"
                                )
                            }
                        }

                        FloatingActionButton(
                            onClick = {
                                isMuted = !isMuted
                                onUpdateMedia(isMuted, isVideoEnabled)
                            },
                            containerColor = if (isMuted) Color.White else Color.White.copy(alpha = 0.18f),
                            contentColor = if (isMuted) EmeraldDeep else Color.White,
                            shape = CircleShape,
                            modifier = Modifier.size(54.dp)
                        ) {
                            Icon(
                                imageVector = if (isMuted) Icons.Filled.MicOff else Icons.Filled.Mic,
                                contentDescription = "Toggle microphone mute"
                            )
                        }

                        FloatingActionButton(
                            onClick = { onEndCall(elapsedSeconds) },
                            containerColor = CallDangerRed,
                            contentColor = Color.White,
                            shape = CircleShape,
                            modifier = Modifier
                                .size(60.dp)
                                .testTag("end_call_button")
                        ) {
                            Icon(Icons.Filled.CallEnd, contentDescription = "End call")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CameraPreviewSurface(modifier: Modifier = Modifier) {
    val lifecycleOwner = LocalLifecycleOwner.current
    AndroidView(
        factory = { ctx ->
            val previewView = PreviewView(ctx)
            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
            cameraProviderFuture.addListener({
                try {
                    val cameraProvider = cameraProviderFuture.get()
                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }
                    val selector = if (cameraProvider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)) {
                        CameraSelector.DEFAULT_FRONT_CAMERA
                    } else {
                        CameraSelector.DEFAULT_BACK_CAMERA
                    }
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(lifecycleOwner, selector, preview)
                } catch (_: Exception) {
                    // Graceful no-op if emulator lacks camera HAL
                }
            }, ContextCompat.getMainExecutor(ctx))
            previewView
        },
        modifier = modifier
    )
}
