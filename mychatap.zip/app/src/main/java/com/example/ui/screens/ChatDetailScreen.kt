package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.model.ChatMessage
import com.example.data.model.ChatRoom
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.ui.components.AvatarImage
import com.example.ui.components.EmojiPickerTray
import com.example.ui.components.MessageReceiptIcon
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.LocalChatColors
import com.example.util.MediaUtils
import com.example.util.TimeFormatUtils
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ChatDetailScreen(
    currentUserId: String,
    chatRoom: ChatRoom?,
    messagesState: UiState<List<ChatMessage>>,
    profilesMap: Map<String, UserProfile>,
    onBack: () -> Unit,
    onSendMessage: (type: String, text: String, imageData: String, replyToId: String, replyPreview: String) -> Unit,
    onDeleteMessage: (String) -> Unit,
    onTypingChanged: (Boolean) -> Unit,
    onStartCall: (UserProfile, String) -> Unit,
    onUpdateGroup: (title: String, desc: String, photo: String, participantIds: List<String>, adminIds: List<String>) -> Unit
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val chatColors = LocalChatColors.current

    var draftText by remember { mutableStateOf("") }
    var showEmojiTray by remember { mutableStateOf(false) }
    var replyingTo by remember { mutableStateOf<ChatMessage?>(null) }
    var fullScreenImageUri by remember { mutableStateOf<String?>(null) }
    var showGroupInfoDialog by remember { mutableStateOf(false) }
    var isUploadingImage by remember { mutableStateOf(false) }

    val peerProfile = remember(chatRoom, profilesMap, currentUserId) {
        if (chatRoom != null && !chatRoom.isGroup) {
            val otherUid = chatRoom.participantIds.firstOrNull { it != currentUserId }
            otherUid?.let { profilesMap[it] }
        } else null
    }

    val headerTitle = when {
        chatRoom == null -> "Conversation"
        chatRoom.isGroup -> chatRoom.title.ifBlank { "Group Chat" }
        peerProfile != null -> peerProfile.displayName.ifBlank { chatRoom.title }
        else -> chatRoom.title.ifBlank { "Direct Chat" }
    }

    val othersTyping = remember(chatRoom, currentUserId) {
        chatRoom?.typingUserIds?.filterNot { it == currentUserId } ?: emptyList()
    }

    val headerSubtitle = when {
        othersTyping.isNotEmpty() -> "typing…"
        chatRoom?.isGroup == true -> "${chatRoom.participantIds.size} members"
        peerProfile != null -> TimeFormatUtils.formatPresenceSubtitle(
            isOnline = peerProfile.isOnline,
            showLastSeen = peerProfile.showLastSeen,
            lastSeenAt = peerProfile.lastSeenAt
        )
        else -> "Direct message"
    }

    // Debounced typing indicator lifecycle
    LaunchedEffect(draftText) {
        if (draftText.isNotBlank()) {
            onTypingChanged(true)
            delay(3500L)
            onTypingChanged(false)
        } else {
            onTypingChanged(false)
        }
    }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            isUploadingImage = true
            scope.launch {
                val dataUri = MediaUtils.encodeUriToDataUri(context, uri, maxDimension = 512)
                isUploadingImage = false
                if (dataUri != null) {
                    onSendMessage(
                        "image",
                        draftText.trim(),
                        dataUri,
                        replyingTo?.id ?: "",
                        replyingTo?.text?.take(120) ?: ""
                    )
                    draftText = ""
                    replyingTo = null
                }
            }
        }
    }

    val listState = rememberLazyListState()
    val messageCount = (messagesState as? UiState.Success)?.data?.size ?: 0
    LaunchedEffect(messageCount) {
        if (messageCount > 0) {
            listState.animateScrollToItem(messageCount - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(chatColors.wallpaperBackground)
            .imePadding()
    ) {
        // Top Conversation Header
        Surface(
            color = chatColors.topBarBackground,
            contentColor = chatColors.topBarContent,
            shadowElevation = 4.dp
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .padding(horizontal = 6.dp, vertical = 8.dp)
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("chat_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to chats",
                        tint = chatColors.topBarContent
                    )
                }

                AvatarImage(
                    photoData = if (chatRoom?.isGroup == true) chatRoom.photoData else (peerProfile?.photoData ?: ""),
                    displayName = headerTitle,
                    size = 40.dp,
                    isGroup = chatRoom?.isGroup == true,
                    isOnline = peerProfile?.isOnline == true && peerProfile.showLastSeen
                )

                Spacer(modifier = Modifier.width(10.dp))

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable(enabled = chatRoom?.isGroup == true) {
                            showGroupInfoDialog = true
                        }
                ) {
                    Text(
                        text = headerTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = chatColors.topBarContent,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = headerSubtitle,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (othersTyping.isNotEmpty()) EmeraldAccent else chatColors.topBarContent.copy(alpha = 0.8f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (chatRoom?.isGroup == false && peerProfile != null) {
                    IconButton(
                        onClick = { onStartCall(peerProfile, "video") },
                        modifier = Modifier.testTag("video_call_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Videocam,
                            contentDescription = stringResource(R.string.start_video_call_desc),
                            tint = chatColors.topBarContent
                        )
                    }
                    IconButton(
                        onClick = { onStartCall(peerProfile, "audio") },
                        modifier = Modifier.testTag("audio_call_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Call,
                            contentDescription = stringResource(R.string.start_audio_call_desc),
                            tint = chatColors.topBarContent
                        )
                    }
                } else if (chatRoom?.isGroup == true) {
                    IconButton(
                        onClick = { showGroupInfoDialog = true },
                        modifier = Modifier.testTag("group_info_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Info,
                            contentDescription = "Group Details",
                            tint = chatColors.topBarContent
                        )
                    }
                }
            }
        }

        // Messages Wallpaper & Stream
        val dotColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.04f)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .drawBehind {
                    val step = 36.dp.toPx()
                    var y = 18f
                    while (y < size.height) {
                        var x = 18f
                        while (x < size.width) {
                            drawCircle(color = dotColor, radius = 2.2f, center = Offset(x, y))
                            x += step
                        }
                        y += step
                    }
                }
        ) {
            when (messagesState) {
                is UiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = EmeraldAccent)
                    }
                }
                is UiState.Error -> {
                    Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(messagesState.message, color = MaterialTheme.colorScheme.error)
                    }
                }
                is UiState.Success -> {
                    if (messagesState.data.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(28.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
                                tonalElevation = 2.dp
                            ) {
                                Text(
                                    text = "Messages in this chat are secured by Cloud Firestore zero-trust rules. Say hi! 👋",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(messagesState.data, key = { it.id }) { msg ->
                                MessageBubbleItem(
                                    message = msg,
                                    isMine = msg.senderId == currentUserId,
                                    showSenderName = chatRoom?.isGroup == true && msg.senderId != currentUserId,
                                    onReply = { replyingTo = msg },
                                    onDelete = { onDeleteMessage(msg.id) },
                                    onOpenImage = { fullScreenImageUri = it }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Reply Banner
        AnimatedVisibility(visible = replyingTo != null) {
            replyingTo?.let { target ->
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 4.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(4.dp)
                                .height(34.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(EmeraldAccent)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Replying to ${target.senderName}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = if (target.type == "image" && target.text.isBlank()) "📷 Photo" else target.text,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = { replyingTo = null }) {
                            Icon(Icons.Filled.Close, contentDescription = "Cancel reply")
                        }
                    }
                }
            }
        }

        // Emoji Tray
        AnimatedVisibility(visible = showEmojiTray) {
            EmojiPickerTray(
                onEmojiSelected = { emoji -> draftText += emoji },
                onSendStandaloneEmoji = { emoji ->
                    onSendMessage(
                        "emoji",
                        emoji,
                        "",
                        replyingTo?.id ?: "",
                        replyingTo?.text?.take(120) ?: ""
                    )
                    replyingTo = null
                    showEmojiTray = false
                }
            )
        }

        // Message Composer Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp
        ) {
            Row(
                verticalAlignment = Alignment.Bottom,
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 8.dp)
            ) {
                IconButton(
                    onClick = { showEmojiTray = !showEmojiTray },
                    modifier = Modifier.testTag("toggle_emoji_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.EmojiEmotions,
                        contentDescription = stringResource(R.string.toggle_emoji_desc),
                        tint = if (showEmojiTray) EmeraldAccent else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                OutlinedTextField(
                    value = draftText,
                    onValueChange = { draftText = it },
                    placeholder = { Text(stringResource(R.string.message_input_placeholder)) },
                    maxLines = 4,
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                        unfocusedBorderColor = Color.Transparent
                    ),
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                imagePicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            enabled = !isUploadingImage,
                            modifier = Modifier.testTag("attach_image_button")
                        ) {
                            if (isUploadingImage) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(
                                    imageVector = Icons.Filled.Image,
                                    contentDescription = stringResource(R.string.attach_image_desc)
                                )
                            }
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("message_input_field")
                )

                Spacer(modifier = Modifier.width(8.dp))

                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(EmeraldAccent)
                        .clickable(enabled = draftText.trim().isNotEmpty()) {
                            val trimmed = draftText.trim()
                            val msgType = if (TimeFormatUtils.isSingleOrPureEmoji(trimmed)) "emoji" else "text"
                            onSendMessage(
                                msgType,
                                trimmed,
                                "",
                                replyingTo?.id ?: "",
                                replyingTo?.text?.take(120) ?: ""
                            )
                            draftText = ""
                            replyingTo = null
                        }
                        .testTag("send_message_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = stringResource(R.string.send_message_desc),
                        tint = Color(0xFF043927),
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }

    // Full-Screen Image Viewer Dialog
    if (fullScreenImageUri != null) {
        val bmp = remember(fullScreenImageUri) {
            fullScreenImageUri?.let { MediaUtils.decodeDataUriToImageBitmap(it) }
        }
        Dialog(onDismissRequest = { fullScreenImageUri = null }) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black)
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                if (bmp != null) {
                    Image(
                        bitmap = bmp,
                        contentDescription = "Shared photo",
                        modifier = Modifier.fillMaxWidth(),
                        contentScale = ContentScale.FillWidth
                    )
                }
                IconButton(
                    onClick = { fullScreenImageUri = null },
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Icon(Icons.Filled.Close, contentDescription = "Close preview", tint = Color.White)
                }
            }
        }
    }

    // Group Details / Edit Dialog
    if (showGroupInfoDialog && chatRoom?.isGroup == true) {
        var editedTitle by remember(chatRoom) { mutableStateOf(chatRoom.title) }
        var editedDesc by remember(chatRoom) { mutableStateOf(chatRoom.description) }
        val isAdmin = chatRoom.adminIds.contains(currentUserId)

        AlertDialog(
            onDismissRequest = { showGroupInfoDialog = false },
            title = { Text("Group Info (${chatRoom.participantIds.size} members)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (isAdmin) {
                        OutlinedTextField(
                            value = editedTitle,
                            onValueChange = { editedTitle = it },
                            label = { Text("Group Subject") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = editedDesc,
                            onValueChange = { editedDesc = it },
                            label = { Text("Description") },
                            maxLines = 2
                        )
                    } else {
                        Text(chatRoom.title, style = MaterialTheme.typography.titleMedium)
                        if (chatRoom.description.isNotBlank()) {
                            Text(chatRoom.description, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Text(
                        text = "Participants:",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    chatRoom.participantIds.forEach { uid ->
                        val p = profilesMap[uid]
                        val roleSuffix = if (chatRoom.adminIds.contains(uid)) " (Admin)" else ""
                        Text(
                            text = "• ${if (uid == currentUserId) "You" else (p?.displayName ?: uid.take(8))}$roleSuffix",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                if (isAdmin) {
                    TextButton(onClick = {
                        onUpdateGroup(
                            editedTitle,
                            editedDesc,
                            chatRoom.photoData,
                            chatRoom.participantIds,
                            chatRoom.adminIds
                        )
                        showGroupInfoDialog = false
                    }) {
                        Text("Save")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showGroupInfoDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageBubbleItem(
    message: ChatMessage,
    isMine: Boolean,
    showSenderName: Boolean,
    onReply: () -> Unit,
    onDelete: () -> Unit,
    onOpenImage: (String) -> Unit
) {
    val chatColors = LocalChatColors.current
    var showMenu by remember { mutableStateOf(false) }

    val bubbleShape = if (isMine) {
        RoundedCornerShape(topStart = 16.dp, topEnd = 4.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
    } else {
        RoundedCornerShape(topStart = 4.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
    }

    val decodedImage = remember(message.imageData) {
        if (message.type == "image" && message.imageData.isNotBlank()) {
            MediaUtils.decodeDataUriToImageBitmap(message.imageData)
        } else null
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isMine) Arrangement.End else Arrangement.Start
    ) {
        Box {
            Surface(
                shape = bubbleShape,
                color = if (isMine) chatColors.outgoingBubble else chatColors.incomingBubble,
                shadowElevation = 1.dp,
                modifier = Modifier
                    .widthIn(min = 84.dp, max = 300.dp)
                    .combinedClickable(
                        onClick = {
                            if (message.type == "image" && message.imageData.isNotBlank()) {
                                onOpenImage(message.imageData)
                            }
                        },
                        onLongClick = { showMenu = true }
                    )
            ) {
                Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)) {
                    if (showSenderName) {
                        Text(
                            text = message.senderName,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                    }

                    if (message.replyPreviewText.isNotBlank()) {
                        Surface(
                            color = Color.Black.copy(alpha = 0.06f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 6.dp)
                        ) {
                            Text(
                                text = message.replyPreviewText,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            )
                        }
                    }

                    if (decodedImage != null) {
                        Image(
                            bitmap = decodedImage,
                            contentDescription = "Image message",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(190.dp)
                                .clip(RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    if (message.text.isNotBlank()) {
                        val isJumboEmoji = message.type == "emoji" && TimeFormatUtils.isSingleOrPureEmoji(message.text)
                        Text(
                            text = message.text,
                            fontSize = if (isJumboEmoji) 36.sp else 15.sp,
                            lineHeight = if (isJumboEmoji) 42.sp else 20.sp,
                            color = if (isMine) chatColors.outgoingBubbleText else chatColors.incomingBubbleText
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.End,
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(
                            text = TimeFormatUtils.formatMessageTime(message.createdAt),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.78f),
                            fontSize = 10.5.sp
                        )
                        if (isMine) {
                            Spacer(modifier = Modifier.width(4.dp))
                            MessageReceiptIcon(status = message.status)
                        }
                    }
                }
            }

            DropdownMenu(
                expanded = showMenu,
                onDismissRequest = { showMenu = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Reply") },
                    leadingIcon = { Icon(Icons.AutoMirrored.Filled.Reply, contentDescription = null) },
                    onClick = {
                        showMenu = false
                        onReply()
                    }
                )
                if (isMine) {
                    DropdownMenuItem(
                        text = { Text("Delete") },
                        leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null) },
                        onClick = {
                            showMenu = false
                            onDelete()
                        }
                    )
                }
            }
        }
    }
}
