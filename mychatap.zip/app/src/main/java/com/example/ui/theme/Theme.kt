package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = EmeraldDeep,
    onPrimary = Color.White,
    primaryContainer = EmeraldMintContainer,
    onPrimaryContainer = OnEmeraldMintContainer,
    secondary = EmeraldAccent,
    onSecondary = Color(0xFF043927),
    secondaryContainer = Color(0xFFE2F9EB),
    onSecondaryContainer = EmeraldDeep,
    tertiary = EmeraldTeal,
    onTertiary = Color.White,
    background = LightBackground,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightTextSecondary,
    outline = Color(0xFFD0DBD5),
    error = CallDangerRed,
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldAccent,
    onPrimary = Color(0xFF032E1F),
    primaryContainer = Color(0xFF005C4B),
    onPrimaryContainer = Color(0xFFD9FDD3),
    secondary = EmeraldTeal,
    onSecondary = Color.White,
    secondaryContainer = DarkTopBar,
    onSecondaryContainer = DarkTextPrimary,
    tertiary = ReadTickBlue,
    onTertiary = Color(0xFF032330),
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkTextSecondary,
    outline = Color(0xFF2E3D47),
    error = Color(0xFFEF5350),
    onError = Color.White
)

@Immutable
data class ChatExtendedColors(
    val topBarBackground: Color,
    val topBarContent: Color,
    val wallpaperBackground: Color,
    val outgoingBubble: Color,
    val outgoingBubbleText: Color,
    val incomingBubble: Color,
    val incomingBubbleText: Color,
    val accentGreen: Color,
    val readTick: Color
)

val LocalChatColors = staticCompositionLocalOf {
    ChatExtendedColors(
        topBarBackground = EmeraldDeep,
        topBarContent = Color.White,
        wallpaperBackground = LightChatWallpaper,
        outgoingBubble = LightOutgoingBubble,
        outgoingBubbleText = LightTextPrimary,
        incomingBubble = LightIncomingBubble,
        incomingBubbleText = LightTextPrimary,
        accentGreen = EmeraldAccent,
        readTick = ReadTickBlue
    )
}

val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MyChatApTheme(
    darkModePreference: String = "system",
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val useDark = when (darkModePreference) {
        "dark" -> true
        "light" -> false
        else -> systemDark
    }

    val colorScheme = if (useDark) DarkColorScheme else LightColorScheme
    val chatColors = if (useDark) {
        ChatExtendedColors(
            topBarBackground = DarkTopBar,
            topBarContent = DarkTextPrimary,
            wallpaperBackground = DarkChatWallpaper,
            outgoingBubble = DarkOutgoingBubble,
            outgoingBubbleText = DarkTextPrimary,
            incomingBubble = DarkIncomingBubble,
            incomingBubbleText = DarkTextPrimary,
            accentGreen = EmeraldAccent,
            readTick = ReadTickBlue
        )
    } else {
        ChatExtendedColors(
            topBarBackground = EmeraldDeep,
            topBarContent = Color.White,
            wallpaperBackground = LightChatWallpaper,
            outgoingBubble = LightOutgoingBubble,
            outgoingBubbleText = LightTextPrimary,
            incomingBubble = LightIncomingBubble,
            incomingBubbleText = LightTextPrimary,
            accentGreen = EmeraldAccent,
            readTick = ReadTickBlue
        )
    }

    CompositionLocalProvider(LocalChatColors provides chatColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            shapes = AppShapes,
            content = content
        )
    }
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MyChatApTheme(
        darkModePreference = if (darkTheme) "dark" else "light",
        content = content
    )
}
