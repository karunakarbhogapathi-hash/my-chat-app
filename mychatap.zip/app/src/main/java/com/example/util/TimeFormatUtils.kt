package com.example.util

import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object TimeFormatUtils {

    fun formatMessageTime(timestamp: Timestamp?): String {
        val date = timestamp?.toDate() ?: Date()
        return SimpleDateFormat("h:mm a", Locale.getDefault()).format(date)
    }

    fun formatChatListTime(timestamp: Timestamp?): String {
        val date = timestamp?.toDate() ?: return ""
        val nowCal = Calendar.getInstance()
        val msgCal = Calendar.getInstance().apply { time = date }

        val sameYear = nowCal.get(Calendar.YEAR) == msgCal.get(Calendar.YEAR)
        val dayDiff = nowCal.get(Calendar.DAY_OF_YEAR) - msgCal.get(Calendar.DAY_OF_YEAR)

        return when {
            sameYear && dayDiff == 0 -> SimpleDateFormat("h:mm a", Locale.getDefault()).format(date)
            sameYear && dayDiff == 1 -> "Yesterday"
            sameYear && dayDiff in 2..6 -> SimpleDateFormat("EEE", Locale.getDefault()).format(date)
            else -> SimpleDateFormat("MMM d", Locale.getDefault()).format(date)
        }
    }

    fun formatPresenceSubtitle(
        isOnline: Boolean,
        showLastSeen: Boolean,
        lastSeenAt: Timestamp?
    ): String {
        if (!showLastSeen) return "Privacy protected"
        if (isOnline) return "online"
        val date = lastSeenAt?.toDate() ?: return "offline"
        val nowCal = Calendar.getInstance()
        val seenCal = Calendar.getInstance().apply { time = date }
        val sameDay = nowCal.get(Calendar.YEAR) == seenCal.get(Calendar.YEAR) &&
            nowCal.get(Calendar.DAY_OF_YEAR) == seenCal.get(Calendar.DAY_OF_YEAR)

        return if (sameDay) {
            val timeStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(date)
            "last seen today at $timeStr"
        } else {
            val dateStr = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(date)
            "last seen $dateStr"
        }
    }

    fun formatDurationSeconds(seconds: Long): String {
        val mins = seconds / 60
        val secs = seconds % 60
        return String.format(Locale.US, "%02d:%02d", mins, secs)
    }

    fun isSingleOrPureEmoji(text: String): Boolean {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || trimmed.length > 10) return false
        return trimmed.codePoints().allMatch { cp ->
            cp in 0x1F300..0x1FAFF ||
                cp in 0x2600..0x27BF ||
                cp in 0xFE00..0xFE0F ||
                cp == 0x200D ||
                cp == 0x2764
        }
    }
}
