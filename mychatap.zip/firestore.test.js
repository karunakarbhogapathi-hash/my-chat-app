const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const DATABASE_ID = "ai-studio-android-mychatap-5890835e-f5cf-49d3-8e4d-8eae6488dbd3";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const EVE_UID = "eve_789";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function serverTs() {
  // Valid past/current Date accepted by rules (`<= request.time`)
  return new Date(Date.now() - 1000);
}

// --- 1. Unauthenticated Rejections ---
test("Unauthenticated user cannot read profiles or chats", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("profiles").where("isDiscoverable", "==", true).get());
  await assertFails(unauthDb.collection("chats").get());
});

// --- 2. PII Split Isolation ---
test("Owner can create/read own user_private, cross-user get and list are denied", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const ts = serverTs();

  await assertSucceeds(
    aliceDb.collection("user_private").doc(ALICE_UID).set({
      userId: ALICE_UID,
      email: "alice@example.com",
      phoneNumber: "+15551234567",
      readReceiptsEnabled: true,
      notificationsEnabled: true,
      callNotificationsEnabled: true,
      darkModePreference: "system",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  await assertSucceeds(aliceDb.collection("user_private").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("user_private").doc(ALICE_UID).get());
  await assertFails(aliceDb.collection("user_private").get());
});

// --- 3. Profile Creation, Filtered Discovery, Shadow Field & Value Poisoning ---
test("Profile discovery requires isDiscoverable filter and blocks shadow fields", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const ts = serverTs();

  await assertSucceeds(
    aliceDb.collection("profiles").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice Rivera",
      handle: "alice_r",
      about: "Available",
      photoData: "",
      isOnline: true,
      showLastSeen: true,
      isDiscoverable: true,
      lastSeenAt: ts,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Unfiltered query must fail ("rules are not filters")
  await assertFails(bobDb.collection("profiles").get());

  // Aligned query with isDiscoverable == true must succeed
  await assertSucceeds(bobDb.collection("profiles").where("isDiscoverable", "==", true).get());

  // Shadow update with ghost field must fail
  await assertFails(
    aliceDb.collection("profiles").doc(ALICE_UID).update({
      isVerified: true,
      updatedAt: ts,
    })
  );

  // Value poisoning (empty displayName) must fail
  await assertFails(
    aliceDb.collection("profiles").doc(ALICE_UID).update({
      displayName: "",
      updatedAt: ts,
    })
  );
});

// --- 4. Chat & Message Relational Gate + Receipt Progression ---
test("Chat participants can send and mark messages read; outsiders and spoofers are blocked", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const eveDb = testEnv.authenticatedContext(EVE_UID).firestore();
  const ts = serverTs();

  // Orphaned message write before chat exists must fail
  await assertFails(
    aliceDb.collection("chats").doc("chat_ab").collection("messages").doc("msg_orphan").set({
      chatId: "chat_ab",
      senderId: ALICE_UID,
      senderName: "Alice",
      participantIds: [ALICE_UID, BOB_UID],
      type: "text",
      text: "Hello",
      imageData: "",
      replyToMessageId: "",
      replyPreviewText: "",
      status: "sent",
      deliveredTo: [],
      readBy: [],
      isEdited: false,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Create valid direct chat
  await assertSucceeds(
    aliceDb.collection("chats").doc("chat_ab").set({
      chatType: "direct",
      directPairKey: `${ALICE_UID}_${BOB_UID}`,
      title: "Direct Chat",
      description: "",
      photoData: "",
      createdBy: ALICE_UID,
      participantIds: [ALICE_UID, BOB_UID],
      adminIds: [ALICE_UID, BOB_UID],
      lastMessageText: "",
      lastMessageSenderId: "",
      lastMessageSenderName: "",
      lastMessageType: "none",
      typingUserIds: [],
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Eve cannot read chat
  await assertFails(eveDb.collection("chats").doc("chat_ab").get());
  await assertFails(
    eveDb.collection("chats").where("participantIds", "array-contains", EVE_UID).get()
      .then(() => eveDb.collection("chats").doc("chat_ab").get())
  );

  // Alice sends valid message
  await assertSucceeds(
    aliceDb.collection("chats").doc("chat_ab").collection("messages").doc("msg_1").set({
      chatId: "chat_ab",
      senderId: ALICE_UID,
      senderName: "Alice",
      participantIds: [ALICE_UID, BOB_UID],
      type: "text",
      text: "Hey Bob!",
      imageData: "",
      replyToMessageId: "",
      replyPreviewText: "",
      status: "sent",
      deliveredTo: [],
      readBy: [],
      isEdited: false,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Identity spoofing: Alice tries to send message claiming senderId = BOB_UID -> fails
  await assertFails(
    aliceDb.collection("chats").doc("chat_ab").collection("messages").doc("msg_spoof").set({
      chatId: "chat_ab",
      senderId: BOB_UID,
      senderName: "Bob",
      participantIds: [ALICE_UID, BOB_UID],
      type: "text",
      text: "Spoof!",
      imageData: "",
      replyToMessageId: "",
      replyPreviewText: "",
      status: "sent",
      deliveredTo: [],
      readBy: [],
      isEdited: false,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Bob marks message read
  await assertSucceeds(
    bobDb.collection("chats").doc("chat_ab").collection("messages").doc("msg_1").update({
      status: "read",
      deliveredTo: [BOB_UID],
      readBy: [BOB_UID],
      updatedAt: serverTs(),
    })
  );

  // Status regression ('read' -> 'sent') must fail
  await assertFails(
    bobDb.collection("chats").doc("chat_ab").collection("messages").doc("msg_1").update({
      status: "sent",
      updatedAt: serverTs(),
    })
  );
});

// --- 5. Call Signaling & Terminal State Locking ---
test("Call signaling prevents caller self-accept and locks terminal states", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const ts = serverTs();

  await assertSucceeds(
    aliceDb.collection("calls").doc("call_1").set({
      callerId: ALICE_UID,
      callerName: "Alice",
      callerPhotoData: "",
      receiverId: BOB_UID,
      receiverName: "Bob",
      receiverPhotoData: "",
      participantIds: [ALICE_UID, BOB_UID],
      callType: "video",
      status: "ringing",
      sdpOffer: "v=0...",
      sdpAnswer: "",
      isMutedCaller: false,
      isMutedReceiver: false,
      isVideoEnabledCaller: true,
      isVideoEnabledReceiver: true,
      durationSeconds: 0,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Caller cannot self-accept ringing call (State Shortcutting blocked)
  await assertFails(
    aliceDb.collection("calls").doc("call_1").update({
      status: "accepted",
      updatedAt: serverTs(),
    })
  );

  // Receiver accepts call
  await assertSucceeds(
    bobDb.collection("calls").doc("call_1").update({
      status: "accepted",
      sdpAnswer: "v=0 answer...",
      updatedAt: serverTs(),
    })
  );

  // End call
  await assertSucceeds(
    aliceDb.collection("calls").doc("call_1").update({
      status: "ended",
      durationSeconds: 42,
      updatedAt: serverTs(),
    })
  );

  // Terminal state lock: cannot reopen an ended call
  await assertFails(
    bobDb.collection("calls").doc("call_1").update({
      status: "accepted",
      updatedAt: serverTs(),
    })
  );
});
